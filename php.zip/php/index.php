<?php include('head.php'); ?>

<style>
    body {  background-color: #f0f8f7; /* Light green color */ }
    h1 { text-align: center;
           font-size: 48px;
}
</style

<h1>Media Performance Test Page</h1>
<br>
<h1>running on: <?php echo gethostname(); ?></h1>
<br>

<style>
    p { text-align: center; font-size: 28px; }
</style

<p></p>
<br>

<?php
$mysqli = new mysqli($db_rrurl, $db_user, $db_password, $db_name);
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
$sql = "SELECT videoUrl, videoTitle, videoDescription FROM tblVideos";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    echo "<br><br>";
    echo " <style> h1 { text-align: center; font-size: 32px; } </style <h1>Simple Progressive MP4 Example</h1>";
    echo "<div class=\"video-container\">";

    // output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<div class=\"card\">";
        echo "<div class=\"card-body\">";
        echo "<video controls width=640 height=360>";
        echo "<source src=" . $row["videoUrl"] . " type='video/mp4'>";
        echo "Your browser does not support the video tag.";
        echo "</video>";

        echo "<h5 class=\"card-title\">" . $row["videoTitle"] . "</h5>";
        echo "<p class=\"card-text\">" . $row["videoDescription"] . "</p>";
        echo "</div>";
        echo "</div>"; // Close card div
    }
    echo "</div>"; // Close video-container div

} else {
    echo "<p>No videos found</p>";
}
$mysqli->close();
?>
</body>
<?php include ('foot.php'); ?>
