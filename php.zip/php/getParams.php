<?php

require 'AWSSDK/aws.phar';

$ch = curl_init();

# get a valid TOKEN
$headers = array (
        'X-aws-ec2-metadata-token-ttl-seconds: 10' );
$url = "http://169.254.169.254/latest/api/token";

curl_setopt( $ch, CURLOPT_URL, $url );
curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "PUT" );
curl_setopt( $ch, CURLOPT_URL, $url );
$token = curl_exec( $ch );

# then get metadata of the current instance 
$headers = array (
        'X-aws-ec2-metadata-token: '.$token );
$url = "http://169.254.169.254/latest/meta-data/placement/availability-zone";

curl_setopt( $ch, CURLOPT_URL, $url );
curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "GET" );
$az = curl_exec( $ch );

# $az = file_get_contents('http://169.254.169.254/latest/meta-data/placement/availability-zone');
 $region = substr($az, 0, -1);

# fixed by setting IMDSv2 to 'optional' instead of required, (Actions > Instance settings > Modify instance metadata options in console)
# assigned labrole to ec2 instance
$ssm_client = new Aws\Ssm\SsmClient([
    'version' => 'latest',
    'region'  => $region
]);

$result = $ssm_client->GetParametersByPath(['Path' => '/dev']);

$db_masterurl = "";
$db_rrurl = "";
$db_name = "";
$db_user = "";
$db_password = "";

foreach($result['Parameters'] as $p) {
    if ($p['Name'] == '/dev/dbMasterUrl') $db_masterurl = $p['Value'];
    if ($p['Name'] == '/dev/dbRRUrl') $db_rrurl = $p['Value'];
    if ($p['Name'] == '/dev/dbName') $db_name = $p['Value'];
    if ($p['Name'] == '/dev/dbUser') $db_user = $p['Value'];
    if ($p['Name'] == '/dev/dbPassword') $db_password = $p['Value'];
}

?>