<br><br><br><br>
<footer class="gradient">
      <div class="container-fluid text-center">
        <div class="row align-items-center justify-content-center">
          <span class="col-md-4">
            [MARCEL]
          </span>
        </div>
      </div>
    </footer>
  </body>
</html>